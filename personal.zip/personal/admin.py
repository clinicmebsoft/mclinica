# Register your models here.
from django.contrib import admin
from .models import Doctores,Especialidad

admin.site.register(Doctores)
admin.site.register(Especialidad)